<?php

session_start();


$debug_log = "";
$serverName = "MSI\SQL";
$connectionInfo = array("Database" =>"DB", "UID"=>"sa", "PWD"=>"ji3g45s93m06","CharacterSet"=>"UTF-8");
$conn = sqlsrv_connect($serverName, $connectionInfo);

if ($conn){
    
    $debug_log ="Connection established.";

}else{

	$debug_log ="Connection could not be established.";
	die (print_r(sqlsrv_errors(),true));
}

?>

<script>
    var log_message = "<?php echo $debug_log;?>";
    console.log(log_message);
</script>