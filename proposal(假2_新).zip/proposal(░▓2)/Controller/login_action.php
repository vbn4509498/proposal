<?php
include('../Model/connect_db.php');


if(isset($_POST["login"])&&($_POST["login"]=="登入")){
$sql_params =array(
    $_POST['Account'],
    $_POST['Password']
);
$sql_query = "SELECT * FROM Member WHERE Account=(?);";
$stmt = sqlsrv_query($conn,$sql_query,$sql_params);

$row = sqlsrv_fetch_array($stmt);

if(!empty($row['Account'])){
    header("Location: ../index.php");
}else{//下面error的部分要再修改
    echo"<script>
    alert('輸入錯誤');
    window.location.href='../View/login.php';
    </script>";
    
}
sqlsrv_free_stmt($stmt);
$sql_params = array();
}