
<?php
    if(strpos($_SERVER['REQUEST_URI'],"index.php")==true)
    {
        echo'<div class="header">
            <div class="header-l">
                <a href="./index.php" class="title">引流裝置</a>
            </div>
        </div>';
    }
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="./Asset/Css/style.css">
    <link rel="shortcut icon" href="../Asset/Images/favicon.png" type="image/x-icon">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.1/jquery.min.js"></script>
    <title>引流裝置</title>

</head>
<body>
<div id="data"></div>
<div style="display:flex;height:100px;width: 500px;" >
    <canvas id="chart_ph"  class="chart_ph"></canvas>
    <canvas id="chart_tur" class="chart_tur"></canvas>
    <canvas id="chart_wei" class="chart_wei"></canvas>
</div>
</body>
</html>

<!--<form action="./Controller/insert_action.php" method="POST" name = "formInsert" id="formInsert">
    <input type="text" name="weight" value = "">
    <input type="text" name="turbidity" value = "">
    <input type="text" name="ph" value = "">
    <input type="submit"name="insert" value ="新增資料">
</form>-->

<?php
/*include('./Model/connect_db.php');
$sql_query = "
SELECT *
FROM
test
";
$options = array("Scrollable"=>"buffered");
$stmt = sqlsrv_query($conn,$sql_query,array(),$options);

$row_number = sqlsrv_num_rows($stmt);
//共有幾筆資料
while($row = sqlsrv_fetch_array($stmt)){
    echo $row['病人編號'];
    echo $row['流速'];
    echo $row['濃度'];
    echo $row['酸鹼'];
    echo "<a href ='View/update_data.php?id=",$row['病人編號'],"'>修改</a>";
    echo "<a href ='Controller/delete_action.php?id=",$row['病人編號'],"'>刪除</a>","</br>";
}
*/
?>
    



<script language="javascript" type="text/javascript" src="https://cdn.jsdelivr.net/npm/chart.js@2.8.0"></script>

<script >

  $(document).ready(function(e) {
            getRemote();
        });
        var measure_time = [];
        var measure_type= [];
        
        function getRemote () {
            const dataEl = document.getElementById("data");
           $.getJSON('./Controller/get_data.php', function (data) {
                const datas = data[0];
                var i=0;
                if(datas.length > 36){
                    i=datas.length-36;  // 1min / 5sec * 3_type_Data  // can replace it
                }
                
                var str="";
                var pH=[];
                var pH_Time=[];
                var Turbidity=[];
                var Turbidity_Time=[];
                var Weight=[];
                var Weight_Time=[];
                for ( i ; i < datas.length; i++) 
                {   
                    
                    
                   /* var content=`
                    <span>病患身分證：${datas[i].patient_ID}</span>
                    <span>資料：${datas[i].measure_Data}</span>
                    <span>型別：${datas[i].measure_Type}</span>
                    <span>時間：${datas[i].measure_Time.date}</span>
                    <br>`
                    str += content;*/
                    
                    var time = datas[i].measure_Time.date.split(' ');
                    var time1 = time[1].split('.');
                    measure_time.unshift(time1[0]);

                    
                    

                    if (datas[i].measure_Type=="ph"){
                        pH.push(datas[i].measure_Data);
                        pH_Time.push(measure_time[datas.length-i])
                        
                    }else if( datas[i].measure_Type=="tur"){
                        Turbidity.push(datas[i].measure_Data);
                        Turbidity_Time.push(measure_time[datas.length-i]);
                        
                        
                    }else if(datas[i].measure_Type =="wei"){
                        Weight.push(datas[i].measure_Data);
                        Weight_Time.push(measure_time[datas.length-i]);
                        
                    }
                    
                    
                    var ctx_ph = document.getElementById('chart_ph').getContext('2d');
                    var ctx_tur = document.getElementById('chart_tur').getContext('2d');
                    var ctx_wei = document.getElementById('chart_wei').getContext('2d');

                    
                    var myChart_ph = new Chart(ctx_ph, {
                    type: 'line',
                    data: {
                        labels: pH_Time.map(x=>x),
                        datasets: [{
                        label: '酸鹼',
                        data: pH.map(x=>x),
                        fill: false,
                        borderColor: 'rgb(75, 192, 192)',
                        }]
                        },
                    });
                    var myChart_tur = new Chart(ctx_tur, {
                    type: 'line',
                    data: {
                        labels: Turbidity_Time.map(x=>x),
                        datasets: [{
                        label: '濁度',
                        data: Turbidity.map(x=>x),
                        fill: false,
                        borderColor: 'rgb(75, 192, 192)',
                        }]
                        },
                    });
                    var myChart_wei = new Chart(ctx_wei, {
                    type: 'line',
                    data: {
                        labels: Weight_Time.map(x=>x),
                        datasets: [{
                        label: '流速',
                        data: Weight.map(x=>x),
                        fill: false,
                        borderColor: 'rgb(75, 192, 192)',
                        }]
                        },
                    });
                    
                }
                
            dataEl.innerHTML=str;      
            setTimeout(getRemote,2000);
            })
        }
        
</script>