<?php
include('../Model/connect_db.php');

$id = $_GET['id'];
$sql_params = array($id);

$sql_query = "DELETE FROM test WHERE 病人編號=(?);";

$stmt =sqlsrv_query($conn,$sql_query,$sql_params);

if($stmt){
    $debug_log = "Row successfully deleted";
    echo $debug_log;
}else{
    $debug_log = "Delete failed";
    echo $debug_log;
    die(print_r(sqlsrv_errors(),true));
}


sqlsrv_free_stmt($stmt);
$sql_params = array();

header("Location: ../index.php");
die();

?>