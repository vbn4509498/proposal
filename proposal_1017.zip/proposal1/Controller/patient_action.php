<?php include('../Model/connect_db.php');
if(isset($_POST["regist"])&&($_POST["regist"]=="註冊")){
        $id=$_POST['id'];
        $name=$_POST['name'];
        $tel=$_POST['tel'];
        $birth=$_POST['birth'];
        $blood=$_POST['blood'];
        $height=$_POST['height'];
        $weight=$_POST['weight'];
        $doctor_name=$_POST['doctor_name'];
    $sql_params =array(
        $id,
        $name,
        $tel,
        $birth,
        $blood,
        $height,
        $weight,
        $doctor_name
    );
}
if(!empty($id)){
    if(!empty($name)){
        if(!empty($tel)){
            if(!empty($birth)){
                if(!empty($blood)){
                    if(!empty($height)){                   
                        if(!empty($weight)){
                            if(!empty($doctor_name)){$sql_query = "SELECT doctor_ID FROM doctor WHERE doctor_Name = ('$doctor_name')";
                                                    $stmt = sqlsrv_query($conn,$sql_query,$sql_params);
                                                    sqlsrv_free_stmt($stmt);
                                                    $sql_query2="INSERT INTO patient (patient_ID,patient_Name,patient_Tel,patient_Birth,patient_Blood,patient_Height,patient_Weight,doctor_ID)VALUES ('$id','$name','$tel','$birth','$blood','$height','$weight','$stmt');";
                            }else{
                                echo"<script>alert('請輸入醫生');window.location.href='../View/patient_regist.php';</script>";};
                        }else{
                            echo"<script>alert('請輸入體重');window.location.href='../View/patient_regist.php';</script>";};
                    }else{
                    echo"<script>alert('請輸入身高');window.location.href='../View/patient_regist.php';</script>";};
                }else{
                    echo"<script>alert('請輸入血型');window.location.href='../View/patient_regist.php';</script>";};
            }else{
            echo"<script>alert('請輸入生日');window.location.href='../View/patient_regist.php';</script>";};
        }else{
        echo"<script>alert('請輸入電話');window.location.href='../View/patient_regist.php';</script>";};
    }else{
    echo"<script>alert('請輸入姓名');window.location.href='../View/patient_regist.php';</script>";};
}else{
echo"<script>alert('請輸入身分證');window.location.href='../View/patient_regist.php';</script>";
};

if(!empty($sql_query2)){
    $stmt2 = sqlsrv_query($conn,$sql_query2,$sql_params);
    header("Location: ../View/nurse.php");
}
sqlsrv_free_stmt($stmt);
$sql_params = array();
?>