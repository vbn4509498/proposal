<?php
$sql_params = array($_GET['id']);

$sql_query = "SELECT * FROM test WHERE 病人編號=(?)";

$stmt = sqlsrv_query($conn,$sql_query,$sql_params);

$row =sqlsrv_fetch_array($stmt);
$id = $row['病人編號'];
$flowRate = $row['流速'];
$concen = $row['濃度'];
$ph = $row['酸鹼'];


?>