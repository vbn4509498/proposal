<?php
include('../Model/connect_db.php');

if(isset($_POST["regist"])&&($_POST["regist"]=="註冊")){
        $account=$_POST['Account'];
        $password=$_POST['Password'];
        $repassword=$_POST['RePassword'];
        $name=$_POST['name'];
        $tel=$_POST['tel'];
        $type=$_POST['type'];
        $class=$_POST['class'];
    $sql_params =array(
        $account,
        $password,
        $repassword,
        $name,
        $tel,
        $type,
        $class
    );
}
    
    if(!empty($account)){
        if(!empty($password)&&$password==$repassword){
            if(!empty($name)){
                if(!empty($tel)){
                    if(!empty($class)){
                        if($type=='醫生'){
                            $sql_query = "INSERT INTO member (Account,Password,Type)VALUES ('$account','$password','$type');
                                          INSERT INTO doctor (doctor_Name,doctor_Class,doctor_Tel,Account)VALUES('$name','$class','$tel','$account');";
                        }
                        if($type=='護士'){
                            $sql_query = "INSERT INTO member (Account,Password,Type)VALUES ('$account','$password','$type');
                                          INSERT INTO nurse (nurse_Name,nurse_Class,nurse_Tel,Account)VALUES('$name','$class','$tel','$account');";
                        }else{
                        echo"<script>alert('請選擇職稱');window.location.href='../View/regist.php';</script>";};
                    }else{
                        echo"<script>alert('請選擇科別');window.location.href='../View/regist.php';</script>";};
                }else{
                echo"<script>alert('請輸入電話');window.location.href='../View/regist.php';</script>";};
            }else{
            echo"<script>alert('請輸入姓名');window.location.href='../View/regist.php';</script>";};
        }else{
        echo"<script>alert('請重新輸入密碼');window.location.href='../View/regist.php';</script>";};
    }else{
    echo"<script>alert('請選擇帳戶');window.location.href='../View/regist.php';</script>";
};
if(!empty($sql_query)){
    $stmt = sqlsrv_query($conn,$sql_query,$sql_params);
    header("Location: ../View/login.php");
}

sqlsrv_free_stmt($stmt);
$sql_params = array();
