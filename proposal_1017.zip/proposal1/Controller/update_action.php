<?php include('../Model/connect_db.php');

if(isset($_POST["update"])&&($_POST["update"]=="更新資料")){
    $id = $_GET['id'];
    $sql_params =array(
        $_POST['flowRate'],
        $_POST['concen'],
        $_POST['ph'],
        $id
    );

$sql_query = "UPDATE test 
SET 流速=(?),濃度=(?),酸鹼=(?)
WHERE 病人編號=(?);";

$stmt = sqlsrv_query($conn,$sql_query,$sql_params);

if($stmt){
    $debug_log = "Row successfully updated";
    echo $debug_log;
}else{
    $debug_log = "Update failed";
    echo $debug_log;
    die(print_r(sqlsrv_errors(),true));
}

sqlsrv_free_stmt($stmt);
$sql_params = array();

}

header("Location: ../index.php");
die();
?>