<?php
include('../Model/connect_db.php');


if(isset($_POST["login"])&&($_POST["login"]=="登入")){
    $account=$_POST['Account'];
    $password=$_POST['Password'];
$sql_params =array(
    $account,
    $password,
);

$sql_query = "SELECT * FROM member WHERE Account=('$account');";
$stmt = sqlsrv_query($conn,$sql_query,$sql_params);
$row = sqlsrv_fetch_array($stmt);

if(!empty($row['Account'])&& $row['Password']==$password){
    if($row['Type']=='醫生'){
        header("Location: ../View/doctor.php");
    }
    if($row['Type']=='護士'){
        header("Location: ../View/nurse.php");
    }      
}else{
    echo"<script>
    alert('輸入錯誤');
    window.location.href='../View/login.php';
    </script>";
    
}
sqlsrv_free_stmt($stmt);
$sql_params = array();
}