<?php

session_start();


$debug_log = "";
$serverName = "MSI\SQL";
$connectionInfo = array("Database" =>"DB", "UID"=>"sa", "PWD"=>"ji3g45s93m06","CharacterSet"=>"UTF-8");
$conn = sqlsrv_connect($serverName, $connectionInfo);

if ($conn){
    
    $debug_log ="Connection established.";

}else{

	$debug_log ="Connection could not be established.";
	die (print_r(sqlsrv_errors(),true));
}




$sql_query = "
SELECT *
FROM
test
";
$options = array("Scrollable"=>"buffered");
$stmt = sqlsrv_query($conn,$sql_query,array(),$options);

$row_number = sqlsrv_num_rows($stmt);
//共有幾筆資料

$resultSet = array();
$isNotLastResult = true;
$i = 0;

while (!is_null($isNotLastResult))
{
    $resultSet[$i] = array();

    while ($row = sqlsrv_fetch_array($stmt, SQLSRV_FETCH_ASSOC))
    {
        $resultSet[$i][] = $row;
    }

    $isNotLastResult = sqlsrv_next_result($stmt);
    $i++;
}
        
echo json_encode($resultSet,JSON_UNESCAPED_UNICODE);
?>

