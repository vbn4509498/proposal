<?php
include('../Model/connect_db.php');

if(isset($_POST["insert"])&&($_POST["insert"]=="新增資料")){
    $sql_params =array(
        $_POST['flowRate'],
        $_POST['concen'],
        $_POST['ph'],
    );


$sql_query = "INSERT INTO test 
 (流速,濃度,酸鹼)
 VALUES (?,?,?);";

$stmt = sqlsrv_query($conn,$sql_query,$sql_params);

if($stmt){
    $debug_log = "Row successfully updated";
    echo $debug_log;
}else{
    $debug_log = "Update failed";
    echo $debug_log;
    die(print_r(sqlsrv_errors(),true));
}

sqlsrv_free_stmt($stmt);
$sql_params = array();

}

header("Location: ../index.php");
die();









?>