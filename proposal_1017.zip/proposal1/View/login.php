<?php include('../Model/connect_db.php');?>
<?php include('../View/partial/header.php');?>

<div class="form">
<form action="../Controller/login_action.php" method="POST" name = "formaccount" id="formaccount"> 
    <div class="input"><label>帳號：</label><input type="text" name="Account"></div>
    <div class="input"><label>密碼：</label><input type="password" name="Password" ></div>
    
    <input type="submit"name="login" value ="登入" style="width:3.75em;font-size:15px;justify-content:center;margin-left:10.8em;">
</form>
</div>


<style>
    .form{
        height:500px;
        display: flex;
        align-items: center;
        justify-content:center;

    }
    .input{
        display:flex;
    }
    input{
        display:flex;
    }

</style>




