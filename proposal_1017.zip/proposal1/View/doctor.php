<?php include('../Model/connect_db.php');?>
<?php include('../View/partial/header.php');?>


<div class="patient">
<form action="../Controller/patient_action.php" method="POST" name = "formpatient" id="formpatient"> 


<h1>病患資訊</h1>
<label>身分證</label><input type="text" name="id">
<label>姓名</label><input type="text" name="name">
<label>電話</label><input type="text" name="tel">
<label>生日</label><input type="text" name="birth">
<label>血型</label><input type="text" name="blood">
<label>身高</label><input type="text" name="height">
<label>體重</label><input type="text" name="weight">




</form>
</div>
<style>
    h1{
        margin-left:0.63em;
    }
    .patient{
        display:flex;
        justify-content: center;
    }
    label{
        display: flex;
        justify-content: center;
    }
    input{
        display: flex;
        justify-content: center;
    }

</style>

