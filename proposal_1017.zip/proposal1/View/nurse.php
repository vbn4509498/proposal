<?php include('../View/partial/header.php');?>
<form>
    <button formaction="./patient_regist.php">登入病患</button>
    <button formaction="./patient_choose.php">觀測數據</button>
</form>
