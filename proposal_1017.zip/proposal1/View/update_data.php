<?php include('../Model/connect_db.php');?>
<?php include('../Controller/update_read.php');?>
<?php include('../View/partial/header.php');?>
<form action="../Controller/update_action.php?id=<?php echo $id?>" method="POST" name = "formadd" id="formadd"> 
    <input type="text" name="flowRate" value = "<?php echo $flowRate?>">
    <input type="text" name="concen" value = "<?php echo $concen ?>">
    <input type="text" name="ph" value = "<?php echo $ph?>">
    <input type="submit"name="update" value ="更新資料">
</form>