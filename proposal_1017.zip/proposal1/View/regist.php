<?php include('../Model/connect_db.php');?>
<?php include('../View/partial/header.php');?>


<div class="form">
<form action="../Controller/regist_action.php" method="POST" name = "formaccount" id="formaccount"> 
    <label>帳號</label><input type="text" name="Account" >
    <label>密碼</label><input type="password" name="Password" >
    <label>確認密碼</label><input type="password" name="RePassword" >
    <label>姓名</label><input type="text" name="name" >
    <label>電話</label><input type="text" name="tel">
    <label>科別</label><input type="text" name="class">

        <select name="type" style="width:7vw;align-items:center;margin:0.2em;margin-left:4.2em;font-size:15px;">
        <option >
        請選擇職稱
    </option>
        <option >
        醫生
    </option>
    <option >
        護士
    </option>
    </select>
    <input type="submit"name="regist" value ="註冊" style="width:3.75em;font-size:15px;justify-content:center;margin-left:7.6em;">
</form>
</div>


<style>
    
    .form{
        height:500px;
        display: flex;
        align-items: center;
        justify-content:center;
    }
    label{
        display:flex;
    }
    input{
        display:flex;
    }
</style>