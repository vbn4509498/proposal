<link rel="shortcut icon" href="../Asset/Images/favicon.png" type="image/x-icon">
<title>引流裝置</title> 
<div class="header">
        <a href="../index.php" class="title">引流裝置</a>
        <a href="./patient_choose.php" class="title2">觀測數據</a>
</div>
<div class="patient">
<form action="../Controller/patient_action.php" method="POST" name = "formpatient" id="formpatient"> 


<h1>病患資訊</h1>
<label>身分證</label><input type="text" name="id">
<label>姓名</label><input type="text" name="name">
<label>電話</label><input type="text" name="tel">
<label>生日(ex:2000/10/10)</label><input type="text" name="birth">
<label>血型</label><input type="text" name="blood">
<label>身高</label><input type="text" name="height">
<label>體重</label><input type="text" name="weight">
<label>負責醫生</label><input type="text" name="doctor_name">

<input class="regist" type="submit"name="regist" value ="註冊">

</form>
</div>
<style>
    h1{
        margin-left:0.63em;
        
    }
    button{
        margin-top:1em;
        margin-left:9.5em;
    }
    .patient{
        display:flex;
        justify-content: center;
    }
    label{
        display: flex;
        
    }
    input{
        display: flex;
    }
    .regist{
        margin-top:1em;
        margin-left:9.58em;
    }
    .header{
    background-image: linear-gradient(to top, #5ee7df 0%, #b490ca 100%);
    }
    body{
    max-height:100vx;
    display: inline;
    font-size: 16px;
    margin: auto;
    }
    .title{
    font-size: 1.5em;
    text-decoration: none;
    }
    .title2{
        font-size: 1.5em;
        text-decoration: none;
        float:right;
        margin-right:0.2em;
    }
</style>