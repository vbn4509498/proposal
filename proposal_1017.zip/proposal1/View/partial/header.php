<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="../Asset/Css/style.css">
    <link rel="shortcut icon" href="../Asset/Images/favicon.png" type="image/x-icon">
    <title>引流裝置</title>
</head>
<body>

</body>
</html>

<?php
    if(strpos($_SERVER['REQUEST_URI'],"index.php")==true)
    {
        echo'<div class="header">
            <div class="header-l">
                <a href="./index.php" class="title">引流裝置</a></div>
            <div class = "header-r">
                <a href="./View/login.php" class="login">登入會員</a>
                <a href="./View/regist.php" class="regist">加入會員</a>
            </div>
        </div>';
    }else if(strpos($_SERVER['REQUEST_URI'],"login.php")==true){
        
        
        echo'<div class="header"><div class="header-l">
            <a href="../index.php" class="title">引流裝置</a>
        </div>
        </div>';
    }else if(strpos($_SERVER['REQUEST_URI'],"regist.php")==true){
        
        
        echo'
        <div class="header"><div class="header-l">
            <a href="../index.php" class="title">引流裝置</a>
        </div>
        </div>';
    }else if(strpos($_SERVER['REQUEST_URI'],"doctor.php")==true){
        
        
        echo'
        <div class="header"><div class="header-l">
            <a href="../index.php" class="title">引流裝置</a>
        </div>
        </div>';
    }else if(strpos($_SERVER['REQUEST_URI'],"nurse.php")==true){
        
        
        echo'
        <div class="header"><div class="header-l">
            <a href="../index.php" class="title">引流裝置</a>
        </div>
        <div class = "header-r">
        <a href="./View/patient_choose.php" class="login">觀測數據</a>
    </div>
        </div>';
    }
?>
<?php