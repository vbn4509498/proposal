<?php include('../Model/connect_db.php');?>
<?php include('../View/partial/header.php');?>
<?php
$sql_query = "
SELECT *
FROM
test
";
$options = array("Scrollable"=>"buffered");
$stmt = sqlsrv_query($conn,$sql_query,array(),$options);

$row_number = sqlsrv_num_rows($stmt);
//共有幾筆資料

?>

<?php
    while ($row = sqlsrv_fetch_array($stmt)){
        echo $row['病人編號'];
        echo $row['流速'];
        echo $row['濃度'];
        echo $row['酸鹼'],"</br>";
    }



?>
