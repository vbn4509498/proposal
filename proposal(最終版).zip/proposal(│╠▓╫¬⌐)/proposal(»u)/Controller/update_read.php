<?php
$sql_params = array($_GET['id']);

$sql_query = "SELECT * FROM test WHERE patient_ID=(?)";

$stmt = sqlsrv_query($conn,$sql_query,$sql_params);

$row =sqlsrv_fetch_array($stmt);
$weight = $row['重量'];
$turbidity = $row['濃度'];
$ph = $row['酸鹼'];


?>