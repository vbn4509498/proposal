<?php
include('../Model/connect_db.php');

if(isset($_POST["regist"])&&($_POST["regist"]=="註冊")){
    $sql_params =array(
        $_POST['Account'],
        $_POST['Password'],
    );


$sql_query = "INSERT INTO Member 
 (Account,Password)
 VALUES (?,?);";

$stmt = sqlsrv_query($conn,$sql_query,$sql_params);

if($stmt){
    header("Location: ../View/login.php");
}else{
    header("Location: ../View/regist.error.php");
}

sqlsrv_free_stmt($stmt);
$sql_params = array();

}

die();