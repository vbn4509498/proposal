#------------------------------------------
#--- Author: Pradeep Singh
#--- Date: 20th January 2017
#--- Version: 1.0
#--- Python Ver: 2.7
#--- Details At: https://iotbytes.wordpress.com/store-mqtt-data-from-sensors-into-sql-database/
#------------------------------------------
import pyodbc
from datetime import datetime
import time

#=======================連線到資料庫===========================

# ENCRYPT defaults to yes starting in ODBC Driver 18. It's good to always specify ENCRYPT=yes on the client side to avoid MITM attacks.


#=======================End of 連線到資料庫=====================

class DatabaseManager():
	DB_Host = "MSI\SQL"
	DB_Name = "DB"
	DB_User = "sa"
	DB_Password = "ji3g45s93m06"
	conn = pyodbc.connect('DRIVER={SQL Server}; SERVER=' + DB_Host + '; DATABASE=' + DB_Name + '; UID=' + DB_User + '; PWD=' + DB_Password)
	def __init__(self):
	
		pass
		
	def add_del_update_db_record(self, sql_query, args=()):
		self.conn.cursor().execute(sql_query, args)
		self.conn.commit()
		return


#===============================================================
# Functions to push Sensor Data into Database

# Function to save pH, Turbidity, Weight to DB Table
def SensorData(my_dict):
	db_time = (datetime.today()).strftime("%Y-%m-%d %H:%M:%S")
	#Push into DB 
	print(my_dict.get('measure/patient'),my_dict.get('measure/drainage'))
	if len(list(my_dict.keys())) == 5:
		if list(my_dict.keys())[2] == "measure/pH" :
			pH_sensor(my_dict.get('measure/patient'),my_dict.get('measure/drainage'),db_time,my_dict.get('measure/pH'))
		if list(my_dict.keys())[3] == "measure/Turbidity":
			Turbidity_sensor(my_dict.get('measure/patient'),my_dict.get('measure/drainage'),db_time,my_dict.get('measure/Turbidity'))
		if list(my_dict.keys())[4] == "measure/Weight":
			Weight_sensor(my_dict.get('measure/patient'),my_dict.get('measure/drainage'),db_time,my_dict.get('measure/Weight'))

	print ("Inserted pH, Turbidity, Weight Data into Database.")
	print ("")

#===============================================================
# Master Function to Select DB Funtion based on MQTT Topic

def pH_sensor(patient_ID,drainage_ID,db_time,pH_value):
	print(patient_ID,drainage_ID,db_time,pH_value)
	print(type(patient_ID),type(int(drainage_ID)),type(db_time),type(float(pH_value)),"PH")
	dbObj = DatabaseManager()
	dbObj.add_del_update_db_record("insert into dbo.measure(patient_ID,drainage_ID,measure_Time,measure_Data,measure_Type) values (?,?,?,?,?)",[patient_ID,int(drainage_ID),db_time,float(pH_value),"ph"])
	del dbObj
	time.sleep(1)
def Turbidity_sensor(patient_ID,drainage_ID,db_time,tur_value):
	dbObj = DatabaseManager()
	dbObj.add_del_update_db_record("insert into measure (patient_ID,drainage_ID,measure_Time,measure_Data,measure_Type) values (?,?,?,?,?)",[patient_ID,int(drainage_ID),db_time,float(tur_value),"tur"])
	del dbObj
	time.sleep(1)
def Weight_sensor(patient_ID,drainage_ID,db_time,wei_value):
	dbObj = DatabaseManager()
	dbObj.add_del_update_db_record("insert into measure (patient_ID,drainage_ID,measure_Time,measure_Data,measure_Type) values (?,?,?,?,?)",[patient_ID,int(drainage_ID),db_time,float(wei_value),"wei"])
	del dbObj
	time.sleep(1)

def sensor_Data_Handler(my_dict):
	
	if list(my_dict.keys())[0] == "measure/pH":
		SensorData(my_dict)
	elif list(my_dict.keys())[0] == "measure/Turbidity":
		SensorData(my_dict)
	elif list(my_dict.keys())[0] == "measure/Weight":
		SensorData(my_dict)
	elif list(my_dict.keys())[0] == "measure/drainage":
		SensorData(my_dict)
	elif list(my_dict.keys())[0] == "measure/patient":
		SensorData(my_dict)
#===============================================================
