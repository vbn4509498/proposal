#------------------------------------------
#--- Author: Pradeep Singh
#--- Date: 20th January 2017
#--- Version: 1.0
#--- Python Ver: 2.7
#--- Details At: https://iotbytes.wordpress.com/store-mqtt-data-from-sensors-into-sql-database/
#------------------------------------------
import paho.mqtt.client as mqtt
import time
import store_Sensor_Data_to_DB as data
# MQTT Settings 
MQTT_Broker = "172.16.0.50"
MQTT_Port = 1883
Keep_Alive_Interval = 45
MQTT_Topic = "measure/#"
mqttc = mqtt.Client()
my_dict=dict()
#Subscribe to all Sensors at Base Topic
def on_connect(mqttc, userdata, flags, rc):
	print("Connected with result code "+str(rc))
	mqttc.subscribe(MQTT_Topic)

#Save Data into DB Table

def on_message(mqttc, userdata, msg):
	# This is the Master Call for saving MQTT Data into DB
	# For details of "sensor_Data_Handler" function please refer "sensor_data_to_db.py"
	
	payload=msg.payload.decode('utf-8')
	my_dict.update({msg.topic:payload})
	
	data.sensor_Data_Handler(my_dict)

mqttc.on_connect = on_connect

mqttc.on_message = on_message

mqttc.username_pw_set("teacher","password")
# Connect
mqttc.connect(MQTT_Broker, int(MQTT_Port), int(Keep_Alive_Interval))
# Continue the network loop
mqttc.loop_forever()

