
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="style.css">
    <link rel="shortcut icon" href="favicon.png" type="image/x-icon">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.1/jquery.min.js"></script>
    <title>引流裝置</title>

</head>
<body>
<div class="header">
    <div class="header-l">
        <a href="./index.php" class="title">引流裝置</a>
    </div>
</div>
<div class="chart">
<div class="ph_chart">
    <div class = "ph_div">
        <div><h2 class="pow_ph"></h2><button class="button-60" role="button" id="pow_ph_clear">清除</button></div>
        <div><h2 class="restrict_ph"></h2><button  class="button-60" role="button" id="restrict_ph_clear">清除</button></div>
    </div>
    <canvas id="chart_ph"  class="chart_ph"></canvas>
</div>

<div class="tur_chart">
    <canvas id="chart_tur" class="chart_tur"></canvas>
    <div class = "tur_div">
        <div><h2 class="pow_tur"></h2><button id="pow_tur_clear"class="button-60" role="button">清除</button></div>
        <div><h2 class="restrict_tur"></h2><button id="restrict_tur_clear"class="button-60" role="button">清除</button></div>
    </div>    
</div>
<div class="wei_chart">
    <canvas id="chart_wei" class="chart_wei"></canvas>
    <div class = "wei_div">
        <div><h2 class="pow_wei"></h2><button id="pow_wei_clear"class="button-60" role="button">清除</button></div>
        <div><h2 class="restrict_wei"></h2><button id="restrict_wei_clear"class="button-60" role="button">清除</button></div>
    </div>
</div>
</div>
</body>
</html>


<?php
/*include('./Model/connect_db.php');
$sql_query = "
SELECT *
FROM
test
";
$options = array("Scrollable"=>"buffered");
$stmt = sqlsrv_query($conn,$sql_query,array(),$options);

$row_number = sqlsrv_num_rows($stmt);
//共有幾筆資料
while($row = sqlsrv_fetch_array($stmt)){
    echo $row['病人編號'];
    echo $row['流速'];
    echo $row['濃度'];
    echo $row['酸鹼'];
    echo "<a href ='View/update_data.php?id=",$row['病人編號'],"'>修改</a>";
    echo "<a href ='Controller/delete_action.php?id=",$row['病人編號'],"'>刪除</a>","</br>";
}
*/
?>
    


<script language="javascript" type="text/javascript" src="https://cdn.jsdelivr.net/npm/chart.js@2.8.0"></script>

<script >
    var ctx_ph = document.getElementById('chart_ph').getContext('2d');
    var ctx_tur = document.getElementById('chart_tur').getContext('2d');
    var ctx_wei = document.getElementById('chart_wei').getContext('2d');
    var j = 0
    var k = 1
    var measure_Time=k+':'+j;
    const a = 0.6
    var ph=[0]
    var tur=[0]
    var wei=[0]
    var L = 0
    var phL = []
    var turL = []
    var weiL = []
    var measure_ph_pre =0
    var measure_tur_pre=0
    var measure_wei_pre=0
    var ph_count_up=0
    var tur_count_up=0
    var wei_count_up=0
    var ph_count_down=0
    var tur_count_down=0
    var wei_count_down=0
    var ph_error=999999999 
    var tur_error=999999999
    var wei_error=999999999 
    //var phe = [7.0,7.2,7.3,7.2,7.1,7.2,6.9,7.3,7.5,7.6,7.7,7.8,7.8,8.0]
    //var m = 0
    $(document).ready(function(e) {
        getRemote()
    });

        
    function getRemote () {
           for ( var i = 1 ; i < 2; i++)
           {        //m++
                    //if(m>=18){
                     //   m=m%18
                    //}
                    //var measure_ph = phe[m]
                    var measure_ph = (Math.random() * 0.15)+7.15
                    measure_ph = measure_ph.toFixed(2)
                    var measure_tur = Math.floor(Math.random() * 6)+65
                    var measure_wei = Math.floor(Math.random() * 6)+20
                    if(measure_ph_pre<=measure_ph){
                        ph_count_up++
                        ph_count_down=0
                    }else{
                        ph_count_up=0
                        ph_count_down++
                    }
                    if(measure_tur_pre<=measure_tur){
                        tur_count_up++
                        tur_count_down=0
                    }else{
                        tur_count_up=0
                        tur_count_down++
                    }
                    if(measure_wei_pre<=measure_wei){
                        wei_count_up++
                        wei_count_down=0
                    }else{
                        wei_count_up=0
                        wei_count_down++
                    }
                

                    measure_ph_pre=measure_ph
                    measure_tur_pre=measure_tur
                    measure_wei_pre=measure_wei
                    
                    if(Math.abs(measure_ph-ph[L])>ph_error*3){
                        var pow_ph = document.querySelector('.pow_ph')
                        pow_ph.setAttribute('style', 'white-space: pre;');
                        pow_ph.style.visibility = 'visible'
                        pow_ph.style.color = 'red'
                        pow_ph.textContent = "發生異常時間"+" "+measure_Time+"\n"
                        pow_ph.textContent += "實際值"+" "+measure_ph+"\n"
                        pow_ph.textContent += "預測值"+" "+phL
                    }
                    if(Math.abs(measure_tur-tur[L])>tur_error*3){
                        var pow_tur = document.querySelector('.pow_tur')
                        pow_tur.setAttribute('style', 'white-space: pre;');
                        pow_tur.style.visibility = 'visible'
                        pow_tur.style.color = 'red'
                        pow_tur.textContent = "發生異常時間"+" "+measure_Time+"\n"
                        pow_tur.textContent +="實際值"+" "+measure_tur+"\n"
                        pow_tur.textContent +="預測值"+" "+turL
                    }
                    if(Math.abs(measure_wei-wei[L])>wei_error*3){
                        var pow_wei = document.querySelector('.pow_wei')
                        pow_wei.setAttribute('style', 'white-space: pre;');
                        pow_wei.style.visibility = 'visible'
                        pow_wei.style.color = 'red'
                        pow_wei.textContent = "發生異常時間"+" "+measure_Time+"\n"
                        pow_wei.textContent +="實際值"+" "+measure_wei +"\n"
                        pow_wei.textContent +="預測值"+" "+weiL
                    }
                    ph[L+1] = a*measure_ph+(1-a)*ph[L]
                    tur[L+1] = a*measure_tur+(1-a)*tur[L]
                    wei[L+1] = a*measure_wei+(1-a)*wei[L]
                    ph_error=Math.abs(measure_ph-ph[L])
                    tur_error=Math.abs(measure_tur-tur[L])
                    wei_error=Math.abs(measure_wei-wei[L])
                    turL = tur[L+1]
                    weiL = wei[L+1]
                    phL = ph[L+1]
                    phL=phL.toFixed(2)
                    turL=turL.toFixed(2)
                    weiL=weiL.toFixed(2)
                    L=L+1
                    measure_Time=k+':'+j
                    if(j==0){
                        measure_Time=k+':'+"00"
                    }
                    j=j+10
                    if(j==60){
                        k=k+1
                        j=0
                    }
                   if(k==24){
                        k=0
                   }
                   if(ph_count_up>2){
                        document.querySelector('.restrict_ph').style.visibility = 'visible'
                        document.querySelector('.restrict_ph').style.color = 'red'
                        document.querySelector('.restrict_ph').textContent = "趨勢上升時間"+" "+ measure_Time
                    }
                    if(tur_count_up>2){
                        document.querySelector('.restrict_tur').style.visibility = 'visible'
                        document.querySelector('.restrict_tur').style.color = 'red'
                        document.querySelector('.restrict_tur').textContent = "趨勢上升時間"+" "+ measure_Time
                    }
                    if(wei_count_up>2){
                        document.querySelector('.restrict_wei').style.visibility = 'visible'
                        document.querySelector('.restrict_wei').style.color = 'red'
                        document.querySelector('.restrict_wei').textContent = "趨勢上升時間"+" "+ measure_Time
                    }
                    if(ph_count_down>2){
                        document.querySelector('.restrict_ph').style.visibility = 'visible'
                        document.querySelector('.restrict_ph').style.color = 'blue'
                        document.querySelector('.restrict_ph').textContent = "趨勢下降時間"+" "+ measure_Time
                    }
                    /*if(tur_count_down>1){
                        document.querySelector('.restrict_tur').style.visibility = 'visible'
                        document.querySelector('.restrict_tur').style.color = 'blue'
                        document.querySelector('.restrict_tur').textContent = "趨勢下降"+" "+ measure_Time
                    }
                    if(wei_count_down>1){
                        document.querySelector('.restrict_wei').style.visibility = 'visible'
                        document.querySelector('.restrict_wei').style.color = 'blue'
                        document.querySelector('.restrict_wei').textContent = "趨勢下降"+" "+ measure_Time
                    }*/
                   
               if(myChart_ph.data.datasets[0].data.length>11){
                   myChart_ph.data.datasets[0].data.reverse();
                   myChart_ph.data.datasets[0].data.pop();
                   myChart_ph.data.datasets[0].data.reverse();
                   myChart_ph.data.datasets[1].data.reverse();
                   myChart_ph.data.datasets[1].data.pop();
                   myChart_ph.data.datasets[1].data.reverse();
                   myChart_ph.data.labels.reverse();
                   myChart_ph.data.labels.pop();
                   myChart_ph.data.labels.reverse();   
               }
                   myChart_ph.data.datasets[1].data.push(phL)
                   myChart_ph.data.datasets[0].data.push(measure_ph);
                   myChart_ph.data.labels.push(measure_Time);
                   myChart_ph.update();
                    
               if(myChart_tur.data.datasets[0].data.length>11){ 
                   myChart_tur.data.datasets[0].data.reverse();
                   myChart_tur.data.datasets[0].data.pop();
                   myChart_tur.data.datasets[0].data.reverse();
                   myChart_tur.data.datasets[1].data.reverse();
                   myChart_tur.data.datasets[1].data.pop();
                   myChart_tur.data.datasets[1].data.reverse();
                   myChart_tur.data.labels.reverse();
                   myChart_tur.data.labels.pop();
                   myChart_tur.data.labels.reverse();
               }   
                   myChart_tur.data.datasets[1].data.push(turL)
                   myChart_tur.data.datasets[0].data.push(measure_tur);
                   myChart_tur.data.labels.push(measure_Time);
                   myChart_tur.update();
                  
               if(myChart_wei.data.datasets[0].data.length>11){
                   myChart_wei.data.datasets[0].data.reverse();
                   myChart_wei.data.datasets[0].data.pop();
                   myChart_wei.data.datasets[0].data.reverse();
                   myChart_wei.data.datasets[1].data.reverse();
                   myChart_wei.data.datasets[1].data.pop();
                   myChart_wei.data.datasets[1].data.reverse();
                   myChart_wei.data.labels.reverse();
                   myChart_wei.data.labels.pop();
                   myChart_wei.data.labels.reverse();
               }            
                   myChart_wei.data.datasets[1].data.push(weiL)
                   console.log(weiL)
                   myChart_wei.data.datasets[0].data.push(measure_wei);
                   myChart_wei.data.labels.push(measure_Time);
                   myChart_wei.update();
                
           }
           
           setTimeout(getRemote,2000);
       }

    

    var myChart_ph = new Chart(ctx_ph, {
        
        type: 'line',
        data: {
            labels: [],
            datasets: [
            {
            label: '酸鹼',
            data: [],
            fill: false,
            borderColor: 'rgb(75, 192, 192)',
            },
            {
                label: '酸鹼預測',
                data: [],
                fill: false,
                borderColor: 'rgb(255, 000, 000)',
                
            },
            
            ]
        },
        options :{
            responsive:true,
                scales: {
                    yAxes: [{
                        ticks: {
                            min: 5,
                            max: 8,
                            stepSize: 0.1
                }
            }]
        }, 
    },
    });
    var myChart_tur = new Chart(ctx_tur, {
        type: 'line',
        data: {
            labels: [],
            datasets: [{
            label: '濁度',
            data: [],
            fill: false,
            borderColor: 'rgb(75, 192, 192)',
            },
            {
                label: '濁度預測',
                data: [],
                fill: false,
                borderColor: 'rgb(255, 000, 000)',
            },
        ]
            },
            options :{
                scales: {
                    yAxes: [{
                        ticks: {
                            min: 60,
                            max: 80,
                            stepSize: 1
                    },  
                    },             
                    ],
                  
                    
        },
    },
        
        
    });
    var myChart_wei = new Chart(ctx_wei, {
        type: 'line',
        data: {
            labels: [],
            datasets: [{
            label: '流速',
            data: [],
            fill: false,
            borderColor: 'rgb(75, 192, 192)',
            },
            {
                label: '流速預測',
                data: [],
                fill: false,
                borderColor: 'rgb(255, 000, 000)',
            },
        ]
            },
            options :{
                scales: {
                    yAxes: [{
                        ticks: {
                            min: 10,
                            max: 30,
                            stepSize: 1
            }
        }]
    }
},
        });
    const pow_ph_clear = document.getElementById("pow_ph_clear")
    const restrict_ph_clear = document.getElementById("restrict_ph_clear")
    const pow_wei_clear = document.getElementById("pow_wei_clear")
    const restrict_wei_clear = document.getElementById("restrict_wei_clear")
    const pow_tur_clear = document.getElementById("pow_tur_clear")
    const restrict_tur_clear = document.getElementById("restrict_tur_clear")
    pow_ph_clear.addEventListener('click', function () {
        document.querySelector('.pow_ph').textContent="";
    });
    restrict_ph_clear.addEventListener('click', function () {
        document.querySelector('.restrict_ph').textContent="";
    });
    pow_wei_clear.addEventListener('click', function () {
        document.querySelector('.pow_wei').textContent="";
    });
    restrict_wei_clear.addEventListener('click', function () {
        document.querySelector('.restrict_wei').textContent="";
    });
    pow_tur_clear.addEventListener('click', function () {
        document.querySelector('.pow_tur').textContent="";
    });
    restrict_tur_clear.addEventListener('click', function () {
        document.querySelector('.restrict_tur').textContent="";
    });
</script>