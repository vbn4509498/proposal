
<?php
    if(strpos($_SERVER['REQUEST_URI'],"index.php")==true)
    {
        echo'<div class="header">
            <div class="header-l">
                <a href="./index.php" class="title">引流裝置</a>
            </div>
        </div>';
    }
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="./Asset/Css/style.css">
    <link rel="shortcut icon" href="../Asset/Images/favicon.png" type="image/x-icon">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.1/jquery.min.js"></script>
    <title>引流裝置</title>

</head>
<body>
<div id="data"></div>
<div id = "chart" style="display:flex;height:100px;width: 500px;" >
    <canvas id="chart_ph"  class="chart_ph"></canvas>
    <canvas id="chart_tur" class="chart_tur"></canvas>
    <canvas id="chart_wei" class="chart_wei"></canvas>
</div>
</body>
</html>


<?php
/*include('./Model/connect_db.php');
$sql_query = "
SELECT *
FROM
test
";
$options = array("Scrollable"=>"buffered");
$stmt = sqlsrv_query($conn,$sql_query,array(),$options);

$row_number = sqlsrv_num_rows($stmt);
//共有幾筆資料
while($row = sqlsrv_fetch_array($stmt)){
    echo $row['病人編號'];
    echo $row['流速'];
    echo $row['濃度'];
    echo $row['酸鹼'];
    echo "<a href ='View/update_data.php?id=",$row['病人編號'],"'>修改</a>";
    echo "<a href ='Controller/delete_action.php?id=",$row['病人編號'],"'>刪除</a>","</br>";
}
*/
?>
    


<script language="javascript" type="text/javascript" src="https://cdn.jsdelivr.net/npm/chart.js@2.8.0"></script>

<script >
    var ctx_ph = document.getElementById('chart_ph').getContext('2d');
    var ctx_tur = document.getElementById('chart_tur').getContext('2d');
    var ctx_wei = document.getElementById('chart_wei').getContext('2d');
    var j = 0
    var k = 1
    var measure_Time=k+':'+j;
    const a = 0.6
    var ph=[0]
    var tur=[0]
    var wei=[0]
    var L = 0
    var measure_ph_pre =0
    var measure_tur_pre=0
    var measure_wei_pre=0
    var ph_count_up=0
    var tur_count_up=0
    var wei_count_up=0
    var ph_count_down=0
    var tur_count_down=0
    var wei_count_down=0
    var ph_error=999999999 
    var tur_error=999999999
    var wei_error=999999999 
$(document).ready(function(e) {
        getRemote()
    });

        
    function getRemote () {
           for ( var i = 1 ; i < 2; i++)
           {        
                    var measure_ph = (Math.random() * 0.75)+7.25
                    var measure_tur = Math.floor(Math.random() * 11)+60
                    var measure_wei = Math.floor(Math.random() * 11)+60
                    if(measure_ph_pre<=measure_ph){
                        ph_count_up++
                        ph_count_down=0
                    }else{
                        ph_count_up=0
                        ph_count_down++
                    }
                    if(measure_tur_pre<=measure_tur){
                        tur_count_up++
                        tur_count_down=0
                    }else{
                        tur_count_up=0
                        tur_count_down++
                    }
                    if(measure_wei_pre<=measure_wei){
                        wei_count_up++
                        wei_count_down=0
                    }else{
                        wei_count_up=0
                        wei_count_down++
                    }
                    if(ph_count_up>5){
                        console.log('ph_up')
                    }
                    if(tur_count_up>5){
                        console.log('tur_up')
                    }
                    if(wei_count_up>5){
                        console.log('wei_up')
                    }
                    if(ph_count_down>5){
                        console.log('ph_down')
                    }
                    if(tur_count_down>5){
                        console.log('tur_down')
                    }
                    if(wei_count_down>5){
                        console.log('wei_down')
                    }
                    measure_ph_pre=measure_ph
                    measure_tur_pre=measure_tur
                    measure_wei_pre=measure_wei
                    if(Math.abs(measure_ph-ph[L])>ph_error*2)
                        console.log('ph_error')
                    if(Math.abs(measure_tur-tur[L])>tur_error*2)
                        console.log('tur_error')
                    if(Math.abs(measure_wei-wei[L])>wei_error*2)
                        console.log('wei_error')

                    ph[L+1] = a*measure_ph+(1-a)*ph[L]
                    tur[L+1] = a*measure_tur+(1-a)*tur[L]
                    wei[L+1] = a*measure_wei+(1-a)*wei[L]

                    ph_error=Math.abs(measure_ph-ph[L])
                    tur_error=Math.abs(measure_tur-tur[L])
                    wei_error=Math.abs(measure_wei-wei[L])

                    // console.log(Math.abs(measure_ph-ph[L]))
                    // console.log(Math.abs(measure_tur-tur[L]))
                    // console.log(Math.abs(measure_wei-wei[L]))

                    L=L+1
                    measure_Time=k+':'+j
                    j=j+10
                    if(j==60){
                        k=k+1
                        j=0
                    }
                   if(k==24){
                        k=0
                   }
                   
                   
               if(myChart_ph.data.datasets[0].data.length>11){
                  myChart_ph.data.datasets[0].data.reverse();
                   myChart_ph.data.datasets[0].data.pop();
                   myChart_ph.data.datasets[0].data.reverse();
                   myChart_ph.data.labels.reverse();
                   myChart_ph.data.labels.pop();
                   myChart_ph.data.labels.reverse();   
               }
                   myChart_ph.data.datasets[0].data.push(measure_ph);
                   myChart_ph.data.labels.push(measure_Time);
                   myChart_ph.update();
                    
               if(myChart_tur.data.datasets[0].data.length>11){ 
                   myChart_tur.data.datasets[0].data.reverse();
                   myChart_tur.data.datasets[0].data.pop();
                   myChart_tur.data.datasets[0].data.reverse();
                   myChart_tur.data.labels.reverse();
                   myChart_tur.data.labels.pop();
                   myChart_tur.data.labels.reverse();
               }           
                   myChart_tur.data.datasets[0].data.push(measure_tur);
                   myChart_tur.data.labels.push(measure_Time);
                   myChart_tur.update();
                  
               if(myChart_wei.data.datasets[0].data.length>11){
                   myChart_wei.data.datasets[0].data.reverse();
                   myChart_wei.data.datasets[0].data.pop();
                   myChart_wei.data.datasets[0].data.reverse();
                   myChart_wei.data.labels.reverse();
                   myChart_wei.data.labels.pop();
                   myChart_wei.data.labels.reverse();
               }            
                   myChart_wei.data.datasets[0].data.push(measure_wei);
                   myChart_wei.data.labels.push(measure_Time);
                   myChart_wei.update();
                
           }
           
           setTimeout(getRemote,2000);
       }
        

    var myChart_ph = new Chart(ctx_ph, {
        type: 'line',
        data: {
            labels: [],
            datasets: [{
            label: '酸鹼',
            data: [],
            fill: false,
            borderColor: 'rgb(75, 192, 192)',
            }]
        },
        options :{
                scales: {
                    yAxes: [{
                        ticks: {
                            min: 7,
                            max: 8,
                            stepSize: 0.1 
            }
        }]
    }
},
          
    });
    var myChart_tur = new Chart(ctx_tur, {
        type: 'line',
        data: {
            labels: [],
            datasets: [{
            label: '濁度',
            data: [],
            fill: false,
            borderColor: 'rgb(75, 192, 192)',
            }]
            },
            options :{
                scales: {
                    yAxes: [{
                        ticks: {
                            min: 60,
                            max: 70,
                            stepSize: 1
            }
        }]
    }
},
        
        
        });
    var myChart_wei = new Chart(ctx_wei, {
        type: 'line',
        data: {
            labels: [],
            datasets: [{
            label: '流速',
            data: [],
            fill: false,
            borderColor: 'rgb(75, 192, 192)',
            }]
            },
            options :{
                scales: {
                    yAxes: [{
                        ticks: {
                            min: 60,
                            max: 70,
                            stepSize: 1
            }
        }]
    }
},
        });
    
</script>