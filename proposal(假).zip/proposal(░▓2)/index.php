
<?php
    if(strpos($_SERVER['REQUEST_URI'],"index.php")==true)
    {
        echo'<div class="header">
            <div class="header-l">
                <a href="./index.php" class="title">引流裝置</a>
            </div>
        </div>';
    }
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="./Asset/Css/style.css">
    <link rel="shortcut icon" href="../Asset/Images/favicon.png" type="image/x-icon">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.1/jquery.min.js"></script>
    <title>引流裝置</title>

</head>
<body>
<div id="data"></div>
<div id = "chart" style="display:flex;height:100px;width: 500px;" >
    <canvas id="chart_ph"  class="chart_ph"></canvas>
    <canvas id="chart_tur" class="chart_tur"></canvas>
    <canvas id="chart_wei" class="chart_wei"></canvas>
</div>
</body>
</html>


<?php
/*include('./Model/connect_db.php');
$sql_query = "
SELECT *
FROM
test
";
$options = array("Scrollable"=>"buffered");
$stmt = sqlsrv_query($conn,$sql_query,array(),$options);

$row_number = sqlsrv_num_rows($stmt);
//共有幾筆資料
while($row = sqlsrv_fetch_array($stmt)){
    echo $row['病人編號'];
    echo $row['流速'];
    echo $row['濃度'];
    echo $row['酸鹼'];
    echo "<a href ='View/update_data.php?id=",$row['病人編號'],"'>修改</a>";
    echo "<a href ='Controller/delete_action.php?id=",$row['病人編號'],"'>刪除</a>","</br>";
}
*/
?>
    


<script language="javascript" type="text/javascript" src="https://cdn.jsdelivr.net/npm/chart.js@2.8.0"></script>

<script >
    var ctx_ph = document.getElementById('chart_ph').getContext('2d');
    var ctx_tur = document.getElementById('chart_tur').getContext('2d');
    var ctx_wei = document.getElementById('chart_wei').getContext('2d');
    var j = 0
    var k = 1
    var measure_Time=k+':'+j;

$(document).ready(function(e) {
        getRemote()
    });

        
    function getRemote () {
           for ( var i = 1 ; i < 2; i++)
           {        
                    measure_Time=k+':'+j
                    j=j+10
                    if(j==60){
                        k=k+1
                        j=0
                    }
                   if(k==24){
                        k=0
                   }
                   
                   var measure_ph = (Math.random() * 0.75)+7.25
                   var measure_tur = Math.floor(Math.random() * 6)+60
                   var measure_wei = Math.floor(Math.random() * 6)+60
               if(myChart_ph.data.datasets[0].data.length>11){
                  myChart_ph.data.datasets[0].data.reverse();
                   myChart_ph.data.datasets[0].data.pop();
                   myChart_ph.data.datasets[0].data.reverse();
                   myChart_ph.data.labels.reverse();
                   myChart_ph.data.labels.pop();
                   myChart_ph.data.labels.reverse();   
               }
                   myChart_ph.data.datasets[0].data.push(measure_ph);
                   myChart_ph.data.labels.push(measure_Time);
                   myChart_ph.update();
                    
               if(myChart_tur.data.datasets[0].data.length>11){ 
                   myChart_tur.data.datasets[0].data.reverse();
                   myChart_tur.data.datasets[0].data.pop();
                   myChart_tur.data.datasets[0].data.reverse();
                   myChart_tur.data.labels.reverse();
                   myChart_tur.data.labels.pop();
                   myChart_tur.data.labels.reverse();
               }           
                   myChart_tur.data.datasets[0].data.push(measure_tur);
                   myChart_tur.data.labels.push(measure_Time);
                   myChart_tur.update();
                  
               if(myChart_wei.data.datasets[0].data.length>11){
                   myChart_wei.data.datasets[0].data.reverse();
                   myChart_wei.data.datasets[0].data.pop();
                   myChart_wei.data.datasets[0].data.reverse();
                   myChart_wei.data.labels.reverse();
                   myChart_wei.data.labels.pop();
                   myChart_wei.data.labels.reverse();
               }            
                   myChart_wei.data.datasets[0].data.push(measure_wei);
                   myChart_wei.data.labels.push(measure_Time);
                   myChart_wei.update();
                
           }
           
           setTimeout(getRemote,2000);
       }
        

    var myChart_ph = new Chart(ctx_ph, {
        type: 'line',
        data: {
            labels: [],
            datasets: [{
            label: '酸鹼',
            data: [],
            fill: false,
            borderColor: 'rgb(75, 192, 192)',
            }]
        },
          
    });
    var myChart_tur = new Chart(ctx_tur, {
        type: 'line',
        data: {
            labels: [],
            datasets: [{
            label: '濁度',
            data: [],
            fill: false,
            borderColor: 'rgb(75, 192, 192)',
            }]
            },
         
        
        
        });
    var myChart_wei = new Chart(ctx_wei, {
        type: 'line',
        data: {
            labels: [],
            datasets: [{
            label: '流速',
            data: [],
            fill: false,
            borderColor: 'rgb(75, 192, 192)',
            }]
            },
            
        });
    
</script>